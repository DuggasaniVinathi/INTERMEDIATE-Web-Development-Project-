export const serverUrl =
  import.meta.env.VITE_SERVER_URL || "http://localhost:5001/api";
